/*
	Todo
	1. 获取元素
	2. 每个元素点击事件触发修改数据
	3. 数据用一个数组存，用类的setter来控制
*/


// 获取元素
const selectedItem = document.getElementById('selectedItem')
const form = document.getElementById('itemForm')
const allCheckbox = document.querySelectorAll('input[name=box]')

// 我已经帮你封装好的类
class EditList {
	constructor(target){
		this.dataList = [];
		this.target = target;
//		this.dataStr = ''
	}
	
	add(val){
		this.dataList.push(val)
		this.target.value = this.data
		return this.data
	}
	
	delete(matchVal){
		this.dataList = this.dataList.filter((val)=>{
			return matchVal==val ? false : true
		})
		this.target.value = this.data
		return this.data
	}
	
	get data(){
		return this.dataList.join(';')
	}
}

// 实例化EditList并传入需要显示数据的dom元素
const editList = new EditList(selectedItem) 

// 遍历每一个checkbox的点击,如果是勾选就触发editList.add('xxx')来添加数据
// 如果是反选就触发 editList.delete('xxx')来移除数据
Array.from(allCheckbox).forEach((el,i)=>{
	el.addEventListener('click',(ev)=>{
		if(ev.target.checked){
			editList.add(ev.target.value)
		}else {
			editList.delete(ev.target.value)
		}
	})
})