class Tabs{
    constructor(){
        //获取元素
        this.main=document.getElementById('tab')
        console.log(this.main);

    }
    //初始化
    init(){
    //     for(var i=0;i<this.lis.length;i++){
    //         this.lis.index=i;
    //         this.lis[i].onclick=function(){
    //             console.log(this.index)
    //         }
    //     }
    }

    //切换tab
    togger(){

    }
    //添加
    addtab(){

    }
    //移除
    removeadd(){

    }
    //修改
    edittab(){

    }
}
new Tabs();
