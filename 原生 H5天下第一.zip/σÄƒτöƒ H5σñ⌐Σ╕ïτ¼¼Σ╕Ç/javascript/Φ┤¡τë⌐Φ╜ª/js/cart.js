const doc=document;
let that;
let s=0
class cart{
    constructor(id){
        that=this;
        //获取元素
        this.table=doc.querySelector('table')
        this.check=doc.querySelectorAll('.checkbox');
        this.checkall=doc.querySelectorAll('.checkall');
        this.add=doc.querySelectorAll('.add');
        this.remove=doc.querySelectorAll('.remove');
        this.text=doc.querySelectorAll('.text');
        this.Price=doc.querySelectorAll('.Price');
        this.money=doc.querySelector('.allmoney');
        this.tbody=doc.querySelector('tbody')
        this.tr=doc.querySelectorAll('.tr');
        this.i=doc.querySelector('.i') 
        this.x=doc.querySelectorAll('.x')
        that.a=doc.querySelector('#a');
        this.init();
        console.log(this.x);
    }
    //初始化
    init(){
        that.updatanode()
        that.Money();
        //全选开始事件
        for(let i=0;i<that.checkall.length;i++){
            this.checkall[i].index=i
            this.checkall[i].onclick=this.open
        }
        //全选关闭事件
        for(let i=0;i<that.check.length;i++){
            this.check[i].index=i;
            this.check[i].onclick=this.end
        }
        //数量加1
        for(let i=0;i<this.add.length;i++){
            this.add[i].index=i
            this.add[i].onclick=this.Add
        }
        //数量减1
        for(let i=0;i<this.remove.length;i++){
            //一开始不能减
            this.remove[i].disabled='disabled';
            //鼠标样式为不能点的样式
            this.remove[i].style.cursor='no-drop';
            this.remove[i].index=i;
            this.remove[i].onclick=that.Remove
        }
        //一开始数量都为1
        for(let i=0;i<this.text.length;i++){
            this.text[i].value=1
        }
        // 执行一次删除事件
        that.a.onclick=this.allDelect
        // 执行批量删除事件
        for(let i=0;i<that.x.length;i++){
            that.x[i].onclick=that.Delect
        }
    }

    //重新获取删除后的元素节点
    updatanode(){
        that.checkall=this.table.querySelectorAll('.checkall');
        that.add=this.table.querySelectorAll('.add');
        that.remove=this.table.querySelectorAll('.remove');
        that.text=this.table.querySelectorAll('.text');
        that.Price=this.table.querySelectorAll('.Price');
        that.tr=this.table.querySelectorAll('.tr');
        that.x=this.table.querySelectorAll('.x')
        that.a=this.table.querySelector('#a');
    }
    //全选and全不选
    open(){
        //判断当前全选按钮是否被选中
        if(that.checkall[this.index].checked==true){
            //当前这个全选按钮选中，那么另外一个也要被选中
            for(var i=0;i<that.checkall.length;i++){
                that.checkall[i].checked=true
            }
            //全选按钮被选中了  就让他们全部被选中  checked=true
            for(var i=0;i<that.check.length;i++){
                that.check[i].checked=true
            }
        }else{
            //全选按钮没有被选中就让全部按钮都不选中
            for(var i=0;i<that.check.length;i++){
                that.check[i].checked=false
            }
            for(var i=0;i<that.checkall.length;i++){
                that.checkall[i].checked=false
            }
        }
        //单选框被选中的数量改变那么总价也要改变
        that.Money();
    }
    //如果取消一个checked那么checkall也要取消
    end(){
        that.Money();
        for(var j=0 ; j<that.check.length ; j++){
     
            //判断四个多选框是否全选
            //只要有一个没选中则就不是全选
            that.checkall[1].checked=true
            that.checkall[0].checked = true;
            if(!that.check[j].checked){
                //一旦进入判断，则证明不是全选状态
                //将checkedAllBox设置为没选中状态
                that.checkall[0].checked = false;
                that.checkall[1].checked=false;
                //一旦进入判断，则已经得出结果，不用再继续执行循环
                break;
            }
        }
    }
    //加1
    Add(){
        that.Money()
        // 加1
        that.text[this.index].value=parseInt(that.text[this.index].value)+1
        // 判断有没有大于10
        if(parseInt(that.text[this.index].value)>=10){
            // 大于10 按钮不能被点击
            this.disabled='disabled';
            // 大于10 按钮鼠标样式改变
            this.style.cursor='no-drop';
        }
        // 如果当前的值大于0  ➖按钮的样式变化
        if(parseInt(that.text[this.index].value)>0){
            // 鼠标恢复正常
            that.remove[this.index].style.cursor='auto';
            // 按钮可以点击了
            that.remove[this.index].disabled=false;
        }
        //价格*数量
        let allPrice=parseInt(that.text[this.index].value)*200
        //显示有多少钱
        that.Price[this.index].innerHTML="$"+allPrice+"元"
    }
    //减1
    Remove(){
        //单选框被选中的数量改变那么总价也要改变
        that.Money()
        // 减1
        that.text[this.index].value=parseInt(that.text[this.index].value)-1
        // 判断是不是小于等于1
        if(parseInt(that.text[this.index].value)<=1){
            // 小于等于1 按钮不能被点击
            this.disabled='disabled';
            // 小于等于1 鼠标样式改变
            this.style.cursor='no-drop';
        }
        // 判断当前的值是否大于11
        if(parseInt(that.text[this.index].value)<11){
            // 解放当前加按钮的鼠标样式
            that.add[this.index].style.cursor='auto';
            // 解放当前加按钮
            that.add[this.index].disabled=false;
        }
        //价格*数量
        let allPrice=parseInt(that.text[this.index].value)*200
        //显示有多少钱
        that.Price[this.index].innerHTML="$"+allPrice+"元"
    }

    //总价
    Money(){
        //设置一个价格总数
        let qian=0;
        let all=0;
        //循环当前tr的长度
        for(let i=0;i<that.tr.length;i++){
            //获取tr中的td
            let input=that.tr[i].querySelectorAll('td');
            //获取第一个td中的check
            let chekced=input[0].querySelector('input')
            //判断当前这个check是不是被选中
            if(chekced.checked){
                //通过正则的方法获取里面的数字
                var num= input[4].innerText.replace(/[^0-9]/ig,"");
                all+=1
                //选中的价格想加
                qian+=parseInt(num);
            }
        }
        //总价格
        that.money.innerText='¥'+qian+'元' 
        //总数量
        that.i.innerText=all
    }    
    //单个删除
    Delect(){
        //移除后也要执行一次总价函数
        that.Money();
        //找到要删除的元素的父节点
        let delect=(this.parentNode);
        //删除
        delect.remove()
        //因为删除了tr所以要重新获取一次元素
        that.init();
    }
    //选中的删除
    allDelect(){
        let j=0
        //循环判断一下当前有多少checked被选中
        for(let i=0;i<that.check.length;i++){
            //选中进去这个循环
            if(that.check[i].checked){
                //计算个数
                j+=1
                //找到要删除的父节点
                let delect=(that.check[i].parentNode.parentNode);
                //删除
                that.tbody.removeChild(delect)
            }
        }
        //提示要删除嘛？
        alert(j)
        //因为删除了tr所以要重新获取一次元素
        that.init();
    }
}

new cart('#box')