window.addEventListener('load',()=>{
    const main=document.querySelector('#main')
    limLocation('pin')
    //假的数据
    const imgData=[{'src':'22.jpg'},{'src':'23.jpg'},{'src':'24.jpg'},{'src':'25.jpg'},{'src':'26.jpg'},{'src':'27.jpg'},{'src':'28.jpg'}]
    //滚动条的事件
    this.addEventListener('scroll',()=>{
        if(checkLoad('pin')){
            imgData.map((item)=>{
                //创建div
                const odiv=document.createElement('div')
                odiv.className='pin'
                main.appendChild(odiv);
                const divImg=document.createElement('div')
                divImg.className='box';
                odiv.appendChild(divImg);


                const Img=new Image()
                Img.src='images/'+item.src+'';
                divImg.appendChild(Img)
            })
            limLocation('pin')
        }
    })
})


    //瀑布流
const limLocation=(classname)=>{
    const aContent=getchilds(classname);
    const imgWidth=aContent[0].offsetWidth;
    const num=~~(document.documentElement.clientWidth/imgWidth)
    main.style.cssText='width:'+imgWidth*num+'px;margin:0 auto;';
    const Heightarr=[];
    [].map.call(aContent,(item,index)=>{
        if(index<num){
            Heightarr.push(item.offsetHeight)
        }else{
            // var minHeight=getmin(Heightarr);//获取最小的height
            // var minHeight=Math.min.apply(null,Heightarr)//获取最小的height
            var minHeight=Math.min(...Heightarr)//获取最小的height  通过。。。拓展函数
            //获取最下的height的index值
            const minIndex=getIndex(minHeight,Heightarr)

            //给下一个div位置
            item.style.position='absolute';
            item.style.top=minHeight+'px';
            item.style.left=aContent[minIndex].offsetLeft+'px';

            //刷新
            //        最小的     最小的+当前的offserheight  就让倒数第二小的变成最小的
            Heightarr[minIndex]=Heightarr[minIndex]+item.offsetHeight;
        }
    })   
}

    //滚动条事件
const checkLoad=(classname)=>{
    const aContent=getchilds(classname);
    console.log();
    //获取最后一个图片距离页面的高度
    const lastTop=aContent[aContent.length-1].offsetTop;
    //获取页面高度
    const pageHeight=document.documentElement.clientHeight || document.body.clientHeight;
    //获取滚动条的高度
    const scroolTop=document.documentElement.scrollTop || document.body.scrollTop

    if(pageHeight+scroolTop>lastTop){
        return true
    }
}


//获取name
const getchilds=(classname)=>{
    const arr=[]
    const tagsall=main.querySelectorAll('*');
    [].map.call(tagsall,(value)=>{
        // console.log(1);
        if(value.className==classname){
            arr.push(value)
        }
    })
    return arr
}


//最原始的查找数组中的最小值
const getmin=(arr)=>{
    var arrlength=arr.length;
    for(var i=0, ret=arr[0];i<arrlength;i++){
        ret=Math.min(ret,arr[i]);
    }
    return ret
}

//获取数组中最小值的索引
const getIndex=(minHeight,Heightarr)=>{
    for(var i in Heightarr){
        if(minHeight==Heightarr[i]){
            return i;
            break;
        }
    }
}