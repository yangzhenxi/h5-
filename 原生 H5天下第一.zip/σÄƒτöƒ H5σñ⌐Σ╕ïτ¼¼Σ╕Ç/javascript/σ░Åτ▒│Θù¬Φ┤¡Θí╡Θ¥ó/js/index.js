var that
class Stre{
    constructor(id){
        that=this
        // this.main=document.getElementById(id)
        this.lis=document.querySelectorAll('.all-box-ul-li');
        this.tab=document.querySelectorAll('.all-box-box');
        this.all=document.querySelectorAll('.item');
        this.oneli=document.querySelector('#item')
        this.all_box=document.querySelector('.all-box')
        this.all_box2=document.querySelectorAll('.all-box2')
        console.log(this.all_box2);
        console.log(this.all)
        this.init()
    }
    init(){
        this.oneli.onmouseover=this.togger;
        this.oneli.onmouseleave=this.togger_2;

        this.all_box.onmouseover=this.togger;
        this.all_box.onmouseleave=this.togger_2;


        for(let i=0;i<this.lis.length;i++){
            this.lis[i].index=i;
            this.lis[i].onmouseover=this.Tab;
        }

        for(let i=0;i<this.all.length;i++){
            this.all[i].index=i;
            this.all[i].onmouseover=this.togger2
            this.all[i].onmouseleave=this.togger2_2
        }
    }

    Tab(){
        that.clearclass();
        console.log(this.index)
        that.tab[this.index].style.display='flex'
    }

    clearclass(){
        for(var i=0;i<this.lis.length;i++){
            that.tab[i].style.display='none'
        }
    }
    togger(){
 
        that.all_box.style.display='block'
    }
    togger_2(){
        // if(鼠标不再that.oneli上&&鼠标不再that.all_box上)
        that.all_box.style.display='none'
    }
    togger2(){
        that.all_box2[this.index].style.display='flex'
    }
    togger2_2(){
        that.all_box2[this.index].style.display='none'
    }
}
new Stre('#header-nav')