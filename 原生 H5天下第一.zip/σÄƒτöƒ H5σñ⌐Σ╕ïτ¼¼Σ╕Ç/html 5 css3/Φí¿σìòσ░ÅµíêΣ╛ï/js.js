const doc=document;
const body=document.querySelector('html')
console.log(body);
    
body.onclick=()=>{
    call()
}

const call=()=>{
    const main=document.querySelector('#main')
    main.onclick=()=>{
        console.log(1);
    }
}

